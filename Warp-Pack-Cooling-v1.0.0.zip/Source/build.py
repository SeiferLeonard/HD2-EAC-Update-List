from pathlib import Path
import sys,zipfile,json
root=Path(__file__).resolve().parent
sys.path.insert(0,str(Path(sys.argv[1]).resolve()/'scripts'))
from build_addon import build_addon
output=root.parent/'Warp-Pack-Cooling-v1.0.0.zip'
source=(root/'warppack_cooling.lua').read_bytes()
build_addon('mods/custom/warppack_cooling',source,'e9213626-0a19-4ca9-9b85-0bd2fba649bc',output,'Warp Pack Cooling')
with zipfile.ZipFile(output) as z: files={n:z.read(n) for n in z.namelist()}
m=json.loads(files['manifest.json'])
d='v1.0.0 - Double Warp Pack cooling by default. Configurable teleport distance, heat per warp and cooling via settings.ini. By Miker and ChatGPT/Codex. Requires Bingus Shared Loader API 1.'
m['Description']=d;m['Options'][0]['Description']=d
files['manifest.json']=(json.dumps(m,indent=2)+'\n').encode()
files['Source/warppack_cooling.lua']=source
files['Source/build.py']=Path(__file__).read_bytes()
for name in ('README.txt','DESCRIPTION.txt'):
 files[name]=(root/name).read_bytes()
 files['Source/'+name]=files[name]
with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for name,data in files.items():z.writestr(name,data)
print(output)
