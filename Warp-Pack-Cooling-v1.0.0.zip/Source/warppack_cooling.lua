-- HD2-Addon: mods/custom/warppack_cooling
-- Warp Pack Cooling v1.0.0 - Miker and ChatGPT/Codex. Release build; default cooling verified in game by Miker.
-- Memory reader adapted from the user-supplied M6C addon / our Dagger experiment.
if rawget(_G, 'WarpPackCooling') then return end
local ffi_ok, ffi = pcall(require, 'ffi')
assert(ffi_ok and ffi, 'LuaJIT FFI required')
local CHUNK = 262144
local MEM_COMMIT, MEM_PRIVATE = 0x1000, 0x20000
local PAGE_READONLY, PAGE_READWRITE = 0x02, 0x04
local function is_scannable_protection(p) return p==2 or p==4 or p==0x20 or p==0x40 end
local function build_api()
    -- Every mod shares one LuaJIT VM, so a cdef another mod already made wins. Declare
    -- one at a time and ignore redefinitions, take VirtualQuery's region as an opaque
    -- pointer so a differently-typed prior declaration still matches, and cast our own
    -- call to the typed signature.
    for _, declaration in ipairs({
        'void *GetCurrentProcess(void);',
        'int WriteProcessMemory(void *, void *, const void *, size_t, size_t *);',
        'int VirtualProtect(void *, size_t, uint32_t, uint32_t *);',
        'int ReadProcessMemory(void *process, const void *address, void *buffer, size_t size, size_t *read);',
        'size_t VirtualQuery(const void *address, void *region, size_t size);',
        'int CreateDirectoryA(const char *path, void *security);',
        'uint32_t GetLastError(void);',
        'void *memchr(const void *s, int c, size_t n);',
        'int memcmp(const void *a, const void *b, size_t n);',
    }) do
        pcall(ffi.cdef, declaration)
    end
    -- Uniquely named so it can never collide with another mod's region struct.
    pcall(ffi.cdef, [[typedef struct {
        void *base; void *allocation_base; uint32_t allocation_protection;
        uint16_t partition; uint16_t reserved; size_t size;
        uint32_t state; uint32_t protection; uint32_t type;
    } WarpPackCoolingRegion;]])

    local kernel = ffi.load('kernel32')
    local query = ffi.cast('size_t (*)(const void *, void *, size_t)', kernel.VirtualQuery)
    local process = kernel.GetCurrentProcess()
    local region = ffi.new('WarpPackCoolingRegion[1]')
    local region_size = ffi.sizeof(region[0])
    local counter = ffi.new('size_t[1]')

    -- One scratch buffer for the whole session. Allocating a fresh one per chunk and
    -- then calling ffi.string on it to search turns every megabyte scanned into two
    -- megabytes of garbage -- and this LuaJIT VM is shared with every other mod, so
    -- that collection pressure is not ours alone to pay. Measured on LuaJIT 2.1:
    -- 118 MB/s and 2048 KB of garbage per MB, against 7599 MB/s and 0.2 KB per MB for
    -- the C search below.
    local scratch = ffi.new('uint8_t[?]', CHUNK)

    -- Needles are registered before scanning starts and all of them are looked for in
    -- the same pass over each chunk.
    local needles, longest = {}, 0

    -- memchr/memcmp are byte-exact, so this finds exactly what string.find found --
    -- including a signature at an odd alignment. If another mod declared them with
    -- incompatible types, fall back to the Lua search rather than failing outright.
    local memchr, memcmp
    local c_search = pcall(function()
        memchr, memcmp = ffi.C.memchr, ffi.C.memcmp
        local probe = ffi.new('uint8_t[4]', {1, 2, 3, 4})
        assert(memchr(probe, 3, 4) ~= nil and memcmp(probe, probe, 4) == 0)
    end)

    local self = {}
    self.c_search = c_search

    function self.add_needle(bytes)
        local entry = {text = bytes, len = #bytes, head = bytes:byte(1),
                       data = ffi.new('uint8_t[?]', #bytes)}
        ffi.copy(entry.data, bytes, #bytes)
        needles[#needles + 1] = entry
        if entry.len > longest then longest = entry.len end
        return #needles
    end

    -- Chunks must overlap by at least this much, or a needle straddling the boundary
    -- between two reads is seen by neither.
    function self.longest_needle() return longest end

    -- Pointer arguments are always cast: passing a bare Lua number raises
    -- "cannot convert number to const void *" and kills the whole scan.
    function self.read(address, size)
        if size <= 0 then return nil end
        local buffer = ffi.new('uint8_t[?]', size)
        if kernel.ReadProcessMemory(process, ffi.cast('const void *', address),
                                    buffer, size, counter) == 0 then return nil end
        if tonumber(counter[0]) ~= size then return nil end
        return ffi.string(buffer, size)
    end

    function self.query(address)
        if query(ffi.cast('const void *', address), region, region_size) ~= region_size then
            return nil
        end
        local base = tonumber(ffi.cast('uintptr_t', region[0].base))
        local size = tonumber(region[0].size)
        if not base or not size or size <= 0 then return nil end
        return {base = base, size = size, state = region[0].state,
                protection = region[0].protection, kind = region[0].type,
                -- VirtualQuery's allocation base: the VirtualAlloc that owns this
                -- region. The loader lays the data tables out relative to it, which
                -- is what turns the locate below into a comparison, not a sweep.
                allocation_base = tonumber(ffi.cast('uintptr_t', region[0].allocation_base))}
    end

    -- Read one chunk into the scratch buffer and report every signature hit in it.
    -- Returns false if the chunk could not be read at all.
    function self.scan(address, size, found)
        if size <= 0 or size > CHUNK then return false end
        if kernel.ReadProcessMemory(process, ffi.cast('const void *', address),
                                    scratch, size, counter) == 0 then return false end
        if tonumber(counter[0]) ~= size then return false end
        if c_search then
            for index = 1, #needles do
                local entry = needles[index]
                local cursor, remaining = scratch, size
                while remaining >= entry.len do
                    local hit = memchr(cursor, entry.head, remaining - entry.len + 1)
                    if hit == nil then break end
                    hit = ffi.cast('uint8_t *', hit)
                    local step = tonumber(hit - cursor)
                    if memcmp(hit, entry.data, entry.len) == 0 then
                        found(address + (size - remaining) + step, index)
                    end
                    remaining = remaining - step - 1
                    cursor = hit + 1
                end
            end
        else
            local blob = ffi.string(scratch, size)
            for index = 1, #needles do
                local entry = needles[index]
                local position = 1
                while true do
                    local hit = blob:find(entry.text, position, true)
                    if not hit then break end
                    found(address + hit - 1, index)
                    position = hit + 1
                end
            end
        end
        return true
    end

    function self.address_of(text)
        local ok, value = pcall(function()
            return tonumber(ffi.cast('uintptr_t', ffi.cast('const char *', text)))
        end)
        if ok then return value end
        return nil
    end

    function self.mkdir(path)
        return kernel.CreateDirectoryA(path, nil) ~= 0 or kernel.GetLastError() == 183
    end

    local protect=ffi.cast('int (*)(void *,size_t,uint32_t,uint32_t *)',kernel.VirtualProtect)
    function self.write(address,bytes)
        if #bytes~=4 or address%4~=0 then return false end
        local info=self.query(address)
        if not info or info.state~=MEM_COMMIT or info.kind~=MEM_PRIVATE
            or (info.protection~=2 and info.protection~=4)
            or address<info.base or address+4>info.base+info.size then return false end
        local old=ffi.new('uint32_t[1]')
        local changed=info.protection==2
        if changed and protect(ffi.cast('void *',address),4,4,old)==0 then return false end
        local prior=tonumber(old[0])
        local ok,wrote=pcall(function()
            return kernel.WriteProcessMemory(process,ffi.cast('void *',address),bytes,4,counter)~=0
                and tonumber(counter[0])==4
        end)
        if changed then
            local restored=protect(ffi.cast('void *',address),4,prior,old)~=0
            if not restored then restored=protect(ffi.cast('void *',address),4,prior,old)~=0 end
            local check=self.query(address)
            if not restored or not check or check.protection~=prior then
                error('page protection could not be restored; restart game')
            end
        end
        return ok and wrote
    end
    return self
end


local function fromhex(text) return (text:gsub('..',function(x)return string.char(tonumber(x,16))end)) end
local SIGNATURE=fromhex('4c444c4401000000463581a7')
local ORIGINAL=fromhex('680e9b5d795697b4000000000000000000000000000000000000000000000000000000008a8d91a043b1143700000000000040bfcdcccc3e732560f9817199c200000000f3b3a016f957fffeee7fac98000080bf188f8835fe000000000000009d1f88fe1e3bcd1501000000cdcc4c3ecdcc4c3e0000803f1fb8b9ff0000803f0000803fcdcc4c3e0000004000000040000040400000803f00002041050000003333b33f00008040010000000000704100003442000004420000c04000000000c970558c00002041e7c924a238a38bdbc970558c00000000d3680c5c00000c42e7c924a238a38bdb66cda21c00000000f504802400000c42e7c924a238a38bdbac4de33100000000ecdfd28f00003442e7c924a238a38bdbecdfd28f000000004a15c83a00003442e7c924a238a38bdb4a15c83a000000002008ef3700000000000000000000000000000000050000000000000000002041000000000000000000000000000000000000000000002041000000000000000000000000000000000000000000002041000000000000000000000000000000000000000000002041000000000000000000000000000000000000000000002041000000000000000000000000000000000000000000002041000000000000000000000000000000000000000071d8097f00000000000000000000000000000000bb7a7cf13d2e1f61000000000000000000000000000000009e4b2f1701000000bb7a7cf13d2e1f6100000000000000000000000071d8097f794a62fca07ffb7efaf62ae300000000d398929a0000000002000000794a62fca07ffb7efaf62ae3000000000000000071d8097fbb7a7cf10000000000000000000000000000000000000000f6fdf9fc9cf776de0fd7d61a5bdcf6020000f0410000a0419a99993e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080bf000000000000000000000000000000000000000001000000cdcc4c3ecdcc4c3e00000040000000000000000000000000000000000000000000000000000000000000803f00002041050000003333b33f00008040010000000000704100003442000004420000004100000000000000000000204100000000000000000000000000000000000000000000204100000000000000000000000000000000000000000000204100000000000000000000000000000000000000000000204100000000000000000000000000000000000000000000204100000000000000000000000000000000000000000000204100000000000000000000000000000000000000000000204100000000000000000000000000000000000000000000204100000000000000000000000000000000000000000000204100000000000000000000000000000000000000000000204100000000000000000000000000000000000000000000204100000000000000000000000000000000000000000000204100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000803f000000009a99993e')
local function le(n)
    return string.char(n % 256, math.floor(n / 256) % 256,
                       math.floor(n / 65536) % 256, math.floor(n / 16777216) % 256)
end

local function le_f32(value)
    if value == 0 then return '\0\0\0\0' end
    local sign = 0
    if value < 0 then sign, value = 1, -value end
    -- value = mantissa * 2^exponent with mantissa in [0.5, 1). math.frexp would do this, but it is
    -- gone from Lua 5.3+, and the tests run on newer interpreters as well as the game's 5.1.
    local exponent = math.floor(math.log(value) / math.log(2)) + 1
    local mantissa = value / 2 ^ exponent
    if mantissa >= 1 then mantissa, exponent = mantissa / 2, exponent + 1 end
    if mantissa < 0.5 then mantissa, exponent = mantissa * 2, exponent - 1 end
    exponent = exponent + 126                                  -- bias 127, mantissa in [0.5, 1)
    if exponent <= 0 then return le(sign * 2147483648) end                  -- underflow -> 0
    if exponent >= 255 then return le(sign * 2147483648 + 0x7f800000) end   -- overflow -> inf
    local fraction = math.floor((mantissa * 2 - 1) * 8388608 + 0.5)
    if fraction >= 8388608 then fraction, exponent = 0, exponent + 1 end
    return le(sign * 2147483648 + exponent * 8388608 + fraction)
end

local function parse_config(text)
    local options={enabled=1,teleport_distance=10,heat_per_warp=33,cooling_per_second=12}
    local seen={}
    for line in text:gmatch('[^\r\n]+') do
        line=line:gsub('[#;].*$',''):match('^%s*(.-)%s*$')
        if line~='' then
            local key,value=line:match('^([%a_]+)%s*=%s*(.-)%s*$')
            assert(key and options[key]~=nil,'unknown or malformed setting: '..line)
            assert(not seen[key],'duplicate setting: '..key);seen[key]=true
            assert(value:match('^%d+%.?%d*$'),'use decimal numbers with a dot: '..key)
            options[key]=assert(tonumber(value),'invalid number')
        end
    end
    assert(options.enabled==0 or options.enabled==1,'enabled must be 0 or 1')
    assert(options.teleport_distance>=1 and options.teleport_distance<=100,'teleport_distance must be 1..100')
    assert(options.heat_per_warp>=0 and options.heat_per_warp<=100,'heat_per_warp must be 0..100')
    assert(options.cooling_per_second>=0.1 and options.cooling_per_second<=100,'cooling_per_second must be 0.1..100')
    return options
end
-- Offsets are from the captured LDLD block start, not component-relative.
-- Wiki screenshot corroborates 10m distance, 15/45 thresholds, 33 heat/use, 6 cooling/s.
local fields={{offset=176,key='teleport_distance'},{offset=204,key='heat_per_warp'},{offset=208,key='cooling_per_second'}}
local TARGET,settings
local function configure(options)
    settings=options
    TARGET=ORIGINAL
    for _,field in ipairs(fields) do
        local offset=field.offset-24
        field.bytes=le_f32(options[field.key])
        TARGET=TARGET:sub(1,offset)..field.bytes..TARGET:sub(offset+5)
    end
end
configure(parse_config(''))
local function apply(memory,address)
    local before=memory.read(address,1320)
    if not before or #before~=1320 then return 'unreadable' end
    if before:sub(1,12)~=SIGNATURE or before:sub(13,24)~=fromhex('100500000100000000000000') then return 'header mismatch' end
    local data=before:sub(25)
    if data==TARGET then return 'already' end
    if data~=ORIGINAL then return 'component fingerprint mismatch' end
    local attempted={}
    local ok=pcall(function()
        for _,field in ipairs(fields) do
            if before:sub(field.offset+1,field.offset+4)~=field.bytes then
                attempted[#attempted+1]=field
                assert(memory.write(address+field.offset,field.bytes),'write failed')
            end
        end
        assert(memory.read(address,1320)==before:sub(1,24)..TARGET,'readback mismatch')
    end)
    if ok then return 'patched' end
    local restored=true
    for i=#attempted,1,-1 do
        local field=attempted[i]
        local good,result=pcall(memory.write,address+field.offset,before:sub(field.offset+1,field.offset+4))
        if not good or not result then restored=false end
    end
    local checked,back=pcall(memory.read,address,1320)
    if not restored or not checked or back~=before then error('write failed; rollback not verified - restart game') end
    return 'write failed; original restored'
end
if ...=='warp_test' then return {apply=apply,parse_config=parse_config,configure=configure} end
local api=build_api()
local state={frame=0,cursor=0,bytes=0,patched=0,seen={},done=false}
_G.WarpPackCooling=state
local base=assert(os.getenv('LOCALAPPDATA'),'LOCALAPPDATA missing')
for _,part in ipairs({'CowboyBingus','Helldivers2','WarpPackCooling'}) do
    base=base..'/'..part;assert(api.mkdir(base),'cannot create log folder')
end
local function status(message)
    local f=assert(io.open(base..'/STATUS.txt','w'))
    f:write(message..'\nMatched table copies: '..state.patched..'\nBytes scanned: '..state.bytes..'\n')
    f:close()
end
local config_path=base..'/settings.ini'
local config_ok,options=pcall(function()
    local file=io.open(config_path,'r')
    if file then local text=file:read('*a');file:close();return parse_config(text) end
    local out=assert(io.open(config_path,'w'),'cannot create settings.ini')
    out:write('; Warp Pack Cooling v1.0.0 - restart game after edits.\n; Stock: distance 10m, heat per warp 33, cooling per second 6.\nenabled=1\nteleport_distance=10\nheat_per_warp=33\ncooling_per_second=12\n');out:close()
    return parse_config('')
end)
if not config_ok then status('CONFIGURATION ERROR - '..tostring(options));return end
if options.enabled==0 then status('DISABLED by settings.ini');return end
configure(options)
local summary='distance '..options.teleport_distance..' m; heat/warp '..options.heat_per_warp..'; cooling/s '..options.cooling_per_second
local id=api.add_needle(SIGNATURE)
local current=nil
local function found(address)
    if state.seen[address] then return end
    state.seen[address]=true
    local result=apply(api,address)
    if result=='patched' or result=='already' then
        state.patched=state.patched+1
        print('[WarpPackCooling] '..result..': '..summary)
        status('APPLIED - '..summary)
    end
end
local function tick()
    state.frame=state.frame+1
    if state.frame<120 then return end
    local deadline=os.clock()+0.0015
    while os.clock()<deadline do
        if not current then
            local info=api.query(state.cursor)
            if not info or state.cursor>=0x7FFFFFFF0000 then state.done=true;break end
            local next_address=info.base+info.size
            if next_address<=state.cursor then error('region scan did not advance') end
            state.cursor=next_address
            if info.state==MEM_COMMIT and info.kind==MEM_PRIVATE
                and (info.protection==2 or info.protection==4) then
                current={address=info.base,remaining=info.size}
            end
        else
            local n=math.min(CHUNK,current.remaining)
            -- Queue hits: do not change source pages while the scanner uses its buffer.
            local hits={}
            api.scan(current.address,n,function(address)hits[#hits+1]=address end)
            for _,address in ipairs(hits) do found(address) end
            state.bytes=state.bytes+n
            if n==current.remaining then current=nil else
                current.address=current.address+n-11;current.remaining=current.remaining-n+11
            end
        end
    end
    if state.done then
        status(state.patched>0 and ('DONE - '..summary)
            or 'NO MATCH - Warp Pack unchanged; send STATUS.txt')
    end
end
assert(type(update)=='function','game update callback unavailable')
local previous=update
local function pack(...)return {n=select('#',...),...}end
local function after(...)
    local r=pack(...)
    local ok,err=pcall(tick)
    if not ok then state.done=true;pcall(status,'FAILED - '..tostring(err)) end
    return unpack(r,1,r.n)
end
update=function(...)
    if state.done then return previous(...) end
    return after(previous(...))
end
status('WAITING - v1.0.0; '..summary)
