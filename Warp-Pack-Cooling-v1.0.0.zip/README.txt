Warp Pack Cooling v1.0.0
By Miker and ChatGPT/Codex
Requires Bingus Shared Loader v15 or newer / API 1.

Defaults: teleport distance 10 metres (stock), heat per warp 33 (stock),
cooling per second 12 (stock 6). Only cooling changes by default.
Default double cooling has been verified in game by Miker. Custom distance
and heat settings remain configurable; arbitrary combinations are not validated.

INSTALLATION / UPGRADING
Close the game. Replace the previous Warp Pack Cooling package with this ZIP.
Disable Warp Pack Heat Probe and other Warp Pack gameplay mods. Enable this
mod alongside Bingus Shared Loader, then Purge / Deploy.
The mod keeps the same identity as v0.1.0 and preserves your existing INI.
Wait for APPLIED or DONE in:
%LOCALAPPDATA%\CowboyBingus\Helldivers2\WarpPackCooling\STATUS.txt
The scan can take several minutes. If it reports NO MATCH or FAILED, include
STATUS.txt when reporting the problem. Future game updates may require a mod update.

CONFIGURATION
The first launch creates:
%LOCALAPPDATA%\CowboyBingus\Helldivers2\WarpPackCooling\settings.ini

enabled=1
teleport_distance=10
heat_per_warp=33
cooling_per_second=12

Close the game before editing. Save and restart; no rebuild or redeploy is
needed for INI edits. Existing settings are preserved.
teleport_distance: metres, allowed 1..100; default/stock 10.
heat_per_warp: heat percentage points per use, allowed 0..100; default/stock 33.
cooling_per_second: heat percentage points removed per second, allowed
0.1..100; default 12, stock 6. Larger values mean faster cooling.
These are configuration limits, not gameplay-validated ranges. Longer ranges
may encounter collision/landing restrictions. The shipped cooling setting is the confirmed configuration.
enabled=0 disables changes on the next fresh game launch.
Use decimal points, no duplicate keys. Invalid settings stop the patch.

The safe/unsafe thresholds, upward/downward biases and other component fields
are not edited. The patch matches the captured component before writing,
verifies the result, and attempts rollback on write failure. Unexpected
layouts or conflicting mods are rejected. Original page protection is restored
by the writer. Changes are in memory and end when the game exits.

CREDITS
Miker - concept, capture and gameplay testing.
ChatGPT/Codex - implementation and offline checks.
CowboyBingus - Bingus Shared Loader and addon packaging tools.
Darctor's Helldivers2 RawData - entity/component identification references.
Helldivers Wiki - statistics supplied in the reference screenshot.
Original M6C addon - memory-reader reference used in earlier experiments.

REBUILDING (OPTIONAL)
Editable source is in Source. Install Python 3 and obtain Bingus Shared Loader's
source checkout, then run:
python Source/build.py "path/to/BingusSharedLoader"
The builder writes the release ZIP beside Source. INI edits need no rebuilding.
